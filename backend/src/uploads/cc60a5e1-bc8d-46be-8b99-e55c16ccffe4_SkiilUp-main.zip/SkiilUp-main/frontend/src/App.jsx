// src/App.jsx
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AuthPage } from './components/auth/AuthPage';
import { DisciplinesPage } from './components/student/DisciplinesPage';
import { DisciplineDetail } from './components/student/DisciplineDetail';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { TopicDetail } from './components/student/TopicDetail';
import { AssignmentDetail } from './components/student/AssignmentDetail';
// Импортируем компонент профиля
import { Profile } from './pages/Profile'; // Убедитесь, что путь правильный
import './App.css';

function AppContent() {
  const { isAuthenticated, loading, user } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Загрузка...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <AuthPage />;
  }

  // Show admin dashboard for admins and teachers
  if (user?.role === 'admin' || user?.role === 'teacher') {
    return <AdminDashboard />;
  }

  // Show student routes with disciplines first
  return (
    <Routes>
      <Route path="/" element={<DisciplinesPage />} />
      <Route path="/discipline/:disciplineId" element={<DisciplineDetail />} />
      <Route path="/topics/:id" element={<TopicDetail />} />
      <Route path="/assignments/:id" element={<AssignmentDetail />} />
      <Route path="/profile" element={<Profile />} />
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
