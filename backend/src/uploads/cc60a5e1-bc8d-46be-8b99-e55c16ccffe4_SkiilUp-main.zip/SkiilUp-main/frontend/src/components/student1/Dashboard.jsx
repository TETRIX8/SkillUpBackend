// src/pages/Dashboard.jsx
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import {
  BookOpen,
  FileText,
  CheckCircle,
  Clock,
  AlertCircle,
  User,
  LogOut,
  GraduationCap,
  Calendar,
  Trophy,
  Settings // Добавлена иконка для профиля
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from '../../contexts/AuthContext';
import { apiClient } from '../../lib/api';
import { StatsCards } from '@/components/dashboard/StatsCards';

export const Dashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [topics, setTopics] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      setError('');
      const [topicsResponse, assignmentsResponse, submissionsResponse] = await Promise.all([
        apiClient.getTopics(),
        apiClient.getAssignments(),
        apiClient.getMySubmissions()
      ]);
      setTopics(topicsResponse.topics || []);
      setAssignments(assignmentsResponse.assignments || []);
      setSubmissions(submissionsResponse.submissions || []);
    } catch (error) {
      console.error("Ошибка загрузки данных:", error);
      setError('Ошибка загрузки данных. Пожалуйста, попробуйте позже.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const getSubmissionForAssignment = useCallback((assignmentId) => {
    return submissions.find(sub => sub.assignment_id === assignmentId);
  }, [submissions]);

  const getAssignmentStatus = useCallback((assignment) => {
    const submission = getSubmissionForAssignment(assignment.id);
    if (submission) {
      if (submission.is_graded) {
        return { status: 'graded', label: 'Оценено', color: 'default' };
      }
      return { status: 'submitted', label: 'Отправлено', color: 'secondary' };
    }
    if (assignment.is_overdue) {
      return { status: 'overdue', label: 'Просрочено', color: 'destructive' };
    }
    return { status: 'pending', label: 'Ожидает выполнения', color: 'outline' };
  }, [getSubmissionForAssignment]);

  const renderSkeletonCards = (count) => {
    return Array.from({ length: count }).map((_, index) => (
      <Card key={index} className="overflow-hidden">
        <CardHeader className="pb-3">
          <Skeleton className="h-5 w-3/4 mb-2" />
          <Skeleton className="h-4 w-full" />
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center">
            <Skeleton className="h-4 w-1/3" />
            <Skeleton className="h-8 w-20 rounded-md" />
          </div>
        </CardContent>
      </Card>
    ));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <header className="bg-card border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-3">
                <Skeleton className="h-8 w-8 rounded-full" />
                <Skeleton className="h-6 w-48" />
              </div>
              <div className="flex items-center space-x-4">
                <Skeleton className="h-5 w-24 hidden sm:block" />
                <Skeleton className="h-8 w-20 rounded-md" />
              </div>
            </div>
          </div>
        </header>
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-5 w-96" />
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 mb-8">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-4 sm:p-5">
                  <div className="flex items-center">
                    <Skeleton className="h-7 w-7 rounded-full" />
                    <div className="ml-4 space-y-2">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-6 w-16" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="space-y-6">
            <div className="flex justify-center">
              <Skeleton className="h-9 w-full max-w-md" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {renderSkeletonCards(6)}
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2 sm:space-x-3">
              <div className="bg-primary rounded-full p-2">
                <GraduationCap className="h-5 w-5 sm:h-6 sm:w-6 text-primary-foreground" />
              </div>
              <h1 className="text-lg sm:text-xl font-semibold text-foreground truncate">
                Образовательная платформа
              </h1>
            </div>
            <div className="flex items-center space-x-2 sm:space-x-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="relative h-8 w-8 rounded-full">
                    <div className="bg-primary rounded-full p-1">
                      <User className="h-4 w-4 text-primary-foreground" />
                    </div>
                    <span className="sr-only">Открыть меню пользователя</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">
                        {user?.first_name} {user?.last_name}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground">
                        {user?.email}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigate('/profile')}>
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Профиль</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Выйти</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between">
              {error}
              <Button variant="outline" size="sm" onClick={loadData} className="ml-4">
                Повторить
              </Button>
            </AlertDescription>
          </Alert>
        )}
        <div className="mb-8">
          <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
            Добро пожаловать, {user?.first_name}!
          </h2>
          <p className="text-muted-foreground">
            Здесь вы можете изучать материалы, выполнять задания и отслеживать свой прогресс.
          </p>
        </div>
        <StatsCards topics={topics} assignments={assignments} submissions={submissions} />
        <Tabs defaultValue="topics" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="topics">Темы</TabsTrigger>
            <TabsTrigger value="assignments">Задания</TabsTrigger>
            <TabsTrigger value="grades">Оценки</TabsTrigger>
          </TabsList>
          <TabsContent value="topics" className="space-y-6">
            {topics.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {topics.map((topic) => (
                  <Card 
                    key={topic.id} 
                    className="transition-all duration-200 hover:shadow-lg cursor-pointer group"
                    onClick={() => navigate(`/topics/${topic.id}`)}
                  >
                    <CardHeader>
                      <CardTitle className="group-hover:text-primary transition-colors duration-200">
                        {topic.title}
                      </CardTitle>
                      <CardDescription>{topic.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center">
                        <div className="text-sm text-muted-foreground flex items-center">
                          <BookOpen className="h-4 w-4 mr-1" />
                          {topic.assignments_count} заданий
                        </div>
                        <Button 
                          size="sm" 
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/topics/${topic.id}`);
                          }}
                        >
                          Изучить
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-8 text-center text-muted-foreground">
                  Темы пока недоступны.
                </CardContent>
              </Card>
            )}
          </TabsContent>
          <TabsContent value="assignments" className="space-y-6">
            {assignments.length > 0 ? (
              <div className="space-y-4">
                {assignments.map((assignment) => {
                  const status = getAssignmentStatus(assignment);
                  const submission = getSubmissionForAssignment(assignment.id);
                  return (
                    <Card key={assignment.id} className="transition-shadow duration-200 hover:shadow-md">
                      <CardContent className="p-4 sm:p-6">
                        <div className="space-y-4 sm:space-y-0 sm:flex sm:justify-between sm:items-start">
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-foreground mb-2">
                              {assignment.title}
                            </h3>
                            <p className="text-muted-foreground mb-3">{assignment.description}</p>
                            <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 space-y-1 sm:space-y-0 text-sm text-muted-foreground">
                              <span className="flex items-center">
                                <Trophy className="h-4 w-4 mr-1" />
                                Макс. балл: {assignment.max_score}
                              </span>
                              {assignment.due_date && (
                                <span className="flex items-center">
                                  <Calendar className="h-4 w-4 mr-1" />
                                  Срок: {new Date(assignment.due_date).toLocaleDateString('ru-RU')}
                                </span>
                              )}
                              {submission && submission.is_graded && (
                                <span className="text-green-600 font-medium flex items-center">
                                  <CheckCircle className="h-4 w-4 mr-1" />
                                  Оценка: {submission.score}/{assignment.max_score}
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center justify-between sm:justify-end space-x-3 pt-2 sm:pt-0">
                            <Badge variant={status.color}>{status.label}</Badge>
                            <Button 
                              size="sm" 
                              variant={submission ? "outline" : "default"}
                              onClick={() => navigate(`/assignments/${assignment.id}`)}
                            >
                              {submission ? "Просмотреть" : "Выполнить"}
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <Card>
                <CardContent className="p-8 text-center text-muted-foreground">
                  Задания пока недоступны.
                </CardContent>
              </Card>
            )}
          </TabsContent>
          <TabsContent value="grades" className="space-y-6">
            {submissions.filter(s => s.is_graded).length > 0 ? (
              <div className="space-y-4">
                {submissions.filter(s => s.is_graded).map((submission) => {
                  const relatedAssignment = assignments.find(a => a.id === submission.assignment_id);
                  return (
                    <Card key={submission.id} className="transition-shadow duration-200 hover:shadow-md">
                      <CardContent className="p-4 sm:p-6">
                        <div className="space-y-4 sm:space-y-0 sm:flex sm:justify-between sm:items-start">
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-foreground mb-2">
                              {submission.assignment_title}
                            </h3>
                            {submission.feedback ? (
                              <div className="mb-3">
                                <p className="text-sm font-medium text-muted-foreground mb-1">Обратная связь:</p>
                                <p className="text-foreground bg-muted p-3 rounded-md">{submission.feedback}</p>
                              </div>
                            ) : (
                              <p className="text-muted-foreground mb-3 italic">Обратная связь отсутствует</p>
                            )}
                            <div className="text-sm text-muted-foreground flex items-center">
                              <Calendar className="h-4 w-4 mr-1" />
                              Отправлено: {new Date(submission.submitted_at).toLocaleDateString('ru-RU')}
                            </div>
                          </div>
                          <div className="text-center sm:text-right mt-4 sm:mt-0">
                            <div className="inline-flex flex-col items-center justify-center">
                              <div className="text-3xl font-bold text-green-600">
                                {submission.score}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                из {relatedAssignment?.max_score || 'N/A'}
                              </div>
                              <Badge variant="secondary" className="mt-2">
                                {Math.round((submission.score / (relatedAssignment?.max_score || 100)) * 100)}%
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <Card>
                <CardContent className="p-12 text-center text-muted-foreground">
                  <Trophy className="h-12 w-12 mx-auto mb-4 text-muted-foreground/30" />
                  <h3 className="text-lg font-medium mb-1">Оценок пока нет</h3>
                  <p className="text-sm">Выполните задания, чтобы получить оценки.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};