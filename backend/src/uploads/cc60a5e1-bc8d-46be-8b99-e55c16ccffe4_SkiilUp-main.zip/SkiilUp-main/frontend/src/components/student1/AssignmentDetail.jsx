import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  ArrowLeft, 
  FileText, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  User,
  LogOut,
  GraduationCap,
  Upload,
  Download,
  Send
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { apiClient } from '../../lib/api';

export const AssignmentDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [assignment, setAssignment] = useState(null);
  const [submission, setSubmission] = useState(null);
  const [topic, setTopic] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // Form state
  const [submissionText, setSubmissionText] = useState('');
  const [submissionFile, setSubmissionFile] = useState(null);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    loadAssignmentData();
  }, [id]);

  const loadAssignmentData = async () => {
    try {
      setLoading(true);
      const [assignmentResponse, submissionsResponse] = await Promise.all([
        apiClient.getAssignment(id),
        apiClient.getMySubmissions()
      ]);

      setAssignment(assignmentResponse.assignment);
      
      // Find existing submission for this assignment
      const existingSubmission = submissionsResponse.submissions?.find(
        sub => sub.assignment_id === parseInt(id)
      );
      setSubmission(existingSubmission);
      
      if (existingSubmission) {
        setSubmissionText(existingSubmission.content || '');
        if (existingSubmission.file_path) {
          setUploadedFile({
            file_path: existingSubmission.file_path,
            file_name: existingSubmission.file_name || existingSubmission.file_path
          });
        }
      }

      // Load topic if assignment has topic_id
      if (assignmentResponse.assignment.topic_id) {
        try {
          const topicResponse = await apiClient.getTopic(assignmentResponse.assignment.topic_id);
          setTopic(topicResponse.topic);
        } catch (topicError) {
          console.warn('Could not load topic:', topicError);
        }
      }
    } catch (error) {
      setError('Ошибка загрузки данных: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (file) => {
    if (!file) return null;

    try {
      setUploading(true);
      const formData = new FormData();
      formData.append('file', file);
      formData.append('assignment_id', id);

      const response = await fetch('/api/files/upload', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: formData
      });

      if (!response.ok) {
        throw new Error('Ошибка загрузки файла');
      }

      const result = await response.json();
      setUploadedFile({
        file_path: result.file_path,
        file_name: result.file_name
      });
      
      return {
        file_path: result.file_path,
        file_name: result.file_name
      };
    } catch (error) {
      setError('Ошибка загрузки файла: ' + error.message);
      return null;
    } finally {
      setUploading(false);
    }
  };

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      setSubmissionFile(file);
      await handleFileUpload(file);
    }
  };

  const handleDownloadFile = (filePath, fileName) => {
    const downloadUrl = `/api/files/download/${filePath}`;
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = fileName;
    link.target = '_blank';
    
    // Add authorization header
    fetch(downloadUrl, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    })
    .then(response => response.blob())
    .then(blob => {
      const url = window.URL.createObjectURL(blob);
      link.href = url;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    })
    .catch(error => {
      setError('Ошибка скачивания файла: ' + error.message);
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!submissionText.trim()) {
      setError('Пожалуйста, введите ответ на задание');
      return;
    }

    try {
      setSubmitting(true);
      setError('');
      
      const submissionData = {
        assignment_id: parseInt(id),
        content: submissionText.trim()
      };

      // Add file data if uploaded
      if (uploadedFile) {
        submissionData.file_path = uploadedFile.file_path;
        submissionData.file_name = uploadedFile.file_name;
      }

      if (submission) {
        // Update existing submission
        await apiClient.updateSubmission(submission.id, submissionData);
        setSuccess('Ответ успешно обновлен!');
      } else {
        // Create new submission
        await apiClient.createSubmission(submissionData);
        setSuccess('Ответ успешно отправлен!');
      }
      
      // Reload data to get updated submission
      await loadAssignmentData();
    } catch (error) {
      setError('Ошибка отправки: ' + error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const getAssignmentStatus = () => {
    if (submission) {
      if (submission.is_graded) {
        return { status: 'graded', label: 'Оценено', color: 'default' };
      }
      return { status: 'submitted', label: 'Отправлено', color: 'secondary' };
    }
    
    if (assignment?.is_overdue) {
      return { status: 'overdue', label: 'Просрочено', color: 'destructive' };
    }
    
    return { status: 'pending', label: 'Ожидает выполнения', color: 'outline' };
  };

  const canSubmit = () => {
    return !assignment?.is_overdue || submission; // Can submit if not overdue, or if already has submission (can update)
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Загрузка...</p>
        </div>
      </div>
    );
  }

  if (error && !assignment) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  if (!assignment) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Alert className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>Задание не найдено</AlertDescription>
        </Alert>
      </div>
    );
  }

  const status = getAssignmentStatus();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2 sm:space-x-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => topic ? navigate(`/topics/${topic.id}`) : navigate('/')}
                className="mr-2"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div className="bg-primary rounded-full p-2">
                <GraduationCap className="h-5 w-5 sm:h-6 sm:w-6 text-primary-foreground" />
              </div>
              <h1 className="text-lg sm:text-xl font-semibold text-gray-900 truncate">
                Образовательная платформа
              </h1>
            </div>
            
            <div className="flex items-center space-x-2 sm:space-x-4">
              <div className="hidden sm:flex items-center space-x-2">
                <User className="h-4 w-4 text-gray-500" />
                <span className="text-sm text-gray-700">
                  {user?.first_name} {user?.last_name}
                </span>
              </div>
              <Button variant="outline" size="sm" onClick={logout}>
                <LogOut className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">Выйти</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        {topic && (
          <div className="mb-6">
            <nav className="flex items-center space-x-2 text-sm text-gray-500">
              <button 
                onClick={() => navigate(`/topics/${topic.id}`)}
                className="hover:text-gray-700"
              >
                {topic.title}
              </button>
              <span>/</span>
              <span className="text-gray-900">{assignment.title}</span>
            </nav>
          </div>
        )}

        {/* Assignment Header */}
        <div className="mb-8">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center space-x-3">
              <FileText className="h-8 w-8 text-green-500" />
              <div>
                <h2 className="text-3xl font-bold text-gray-900">{assignment.title}</h2>
                <div className="flex items-center space-x-4 mt-2">
                  <Badge variant={status.color}>{status.label}</Badge>
                  <span className="text-sm text-gray-500">
                    Максимальный балл: {assignment.max_score}
                  </span>
                  {assignment.due_date && (
                    <span className="text-sm text-gray-500">
                      Срок: {new Date(assignment.due_date).toLocaleDateString('ru-RU')}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          {assignment.description && (
            <p className="text-gray-600 text-lg">{assignment.description}</p>
          )}
        </div>

        {/* Assignment Content */}
        {assignment.content && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Описание задания</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                <div dangerouslySetInnerHTML={{ __html: assignment.content }} />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Submission Status */}
        {submission && submission.is_graded && (
          <Alert className="mb-8">
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>
              <div className="flex items-center justify-between">
                <span>Задание оценено: {submission.score}/{assignment.max_score} баллов</span>
              </div>
              {submission.feedback && (
                <div className="mt-2">
                  <strong>Комментарий преподавателя:</strong>
                  <p className="mt-1">{submission.feedback}</p>
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}

        {/* Submission Form */}
        <Card>
          <CardHeader>
            <CardTitle>
              {submission ? 'Ваш ответ' : 'Отправить ответ'}
            </CardTitle>
            <CardDescription>
              {submission 
                ? 'Вы можете обновить свой ответ до окончания срока сдачи'
                : 'Введите ваш ответ на задание'
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            {success && (
              <Alert className="mb-4">
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="submission-text">Ответ на задание</Label>
                <Textarea
                  id="submission-text"
                  value={submissionText}
                  onChange={(e) => setSubmissionText(e.target.value)}
                  placeholder="Введите ваш ответ здесь..."
                  rows={8}
                  disabled={submission?.is_graded || !canSubmit()}
                  className="mt-1"
                />
              </div>

              {/* File Upload */}
              <div>
                <Label htmlFor="submission-file">Прикрепить файл (необязательно)</Label>
                <div className="mt-1">
                  {uploadedFile ? (
                    <div className="flex items-center justify-between p-3 border border-gray-200 rounded-md bg-gray-50">
                      <div className="flex items-center space-x-2">
                        <FileText className="h-4 w-4 text-gray-500" />
                        <span className="text-sm text-gray-700">{uploadedFile.file_name}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleDownloadFile(uploadedFile.file_path, uploadedFile.file_name)}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Скачать
                        </Button>
                        {!submission?.is_graded && canSubmit() && (
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setUploadedFile(null);
                              setSubmissionFile(null);
                            }}
                          >
                            Удалить
                          </Button>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <Input
                        id="submission-file"
                        type="file"
                        onChange={handleFileChange}
                        disabled={submission?.is_graded || !canSubmit() || uploading}
                        accept=".txt,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.rar,.png,.jpg,.jpeg,.gif"
                        className="flex-1"
                      />
                      {uploading && (
                        <div className="flex items-center space-x-2 text-sm text-gray-500">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
                          <span>Загрузка...</span>
                        </div>
                      )}
                    </div>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    Поддерживаемые форматы: TXT, PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX, ZIP, RAR, изображения
                  </p>
                </div>
              </div>

              {canSubmit() && !submission?.is_graded && (
                <div className="flex justify-end">
                  <Button 
                    type="submit" 
                    disabled={submitting || !submissionText.trim()}
                  >
                    {submitting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Отправка...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        {submission ? 'Обновить ответ' : 'Отправить ответ'}
                      </>
                    )}
                  </Button>
                </div>
              )}

              {assignment?.is_overdue && !submission && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Срок сдачи задания истек. Отправка ответа недоступна.
                  </AlertDescription>
                </Alert>
              )}

              {submission?.is_graded && (
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    Задание уже оценено. Изменение ответа недоступно.
                  </AlertDescription>
                </Alert>
              )}
            </form>

            {/* Submission Info */}
            {submission && (
              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="text-sm text-gray-500">
                  <p>Отправлено: {new Date(submission.submitted_at).toLocaleString('ru-RU')}</p>
                  {submission.updated_at && submission.updated_at !== submission.submitted_at && (
                    <p>Обновлено: {new Date(submission.updated_at).toLocaleString('ru-RU')}</p>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

