import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input'; // Добавлен импорт Input
import { ScrollArea } from '@/components/ui/scroll-area'; // Добавлен импорт ScrollArea
import { 
  ArrowLeft, 
  BookOpen, 
  FileText, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  User,
  LogOut,
  GraduationCap,
  MessageCircle, // Добавлена иконка для чат-бота
  Send, // Добавлена иконка отправки
  X // Добавлена иконка закрытия
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { apiClient } from '../../lib/api';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export const TopicDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [topic, setTopic] = useState(null);
  const [assignments, setAssignments] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Состояния для чат-бота
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isBotTyping, setIsBotTyping] = useState(false);
  const messagesEndRef = useRef(null); // Для автопрокрутки

  useEffect(() => {
    loadTopicData();
  }, [id]);

  // Эффект для автопрокрутки чата вниз
  useEffect(() => {
    scrollToBottom();
  }, [chatMessages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const loadTopicData = async () => {
    try {
      setLoading(true);
      const [topicResponse, assignmentsResponse, submissionsResponse] = await Promise.all([
        apiClient.getTopic(id),
        apiClient.getAssignments(),
        apiClient.getMySubmissions()
      ]);
      setTopic(topicResponse.topic);
      // Filter assignments for this topic
      const topicAssignments = assignmentsResponse.assignments?.filter(
        assignment => assignment.topic_id === parseInt(id)
      ) || [];
      setAssignments(topicAssignments);
      setSubmissions(submissionsResponse.submissions || []);
    } catch (error) {
      setError('Ошибка загрузки данных: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const getSubmissionForAssignment = (assignmentId) => {
    return submissions.find(sub => sub.assignment_id === assignmentId);
  };

  const getAssignmentStatus = (assignment) => {
    const submission = getSubmissionForAssignment(assignment.id);
    if (submission) {
      if (submission.is_graded) {
        return { status: 'graded', label: 'Оценено', color: 'default' };
      }
      return { status: 'submitted', label: 'Отправлено', color: 'secondary' };
    }
    if (assignment.is_overdue) {
      return { status: 'overdue', label: 'Просрочено', color: 'destructive' };
    }
    return { status: 'pending', label: 'Ожидает выполнения', color: 'outline' };
  };

  const handleAssignmentClick = (assignmentId) => {
    navigate(`/assignments/${assignmentId}`);
  };

  // Функция для отправки сообщения в чат-бот
  const handleSendMessage = async () => {
    if (!inputMessage.trim() || !topic?.content || isBotTyping) return;

    const userMessage = { role: 'user', content: inputMessage };
    const newMessages = [...chatMessages, userMessage];
    setChatMessages(newMessages);
    setInputMessage('');
    setIsBotTyping(true);

    try {
      // Формируем промт для бота, включая контент темы
      const systemPrompt = `Ты помощник по теме "${topic.title}". 
Используй следующую информацию из темы для ответа на вопросы пользователя. 
Отвечай всегда на русском языке и в формате Markdown (MD). 
Если вопрос не связан с темой, вежливо уточни, что ты можешь помочь только по теме "${topic.title}".

Контент темы:
${topic.content}
`;

      // Отправляем запрос к вашему API
      // Используем fetch для отправки запроса в формате, подобном ChatGPT
      const response = await fetch('https://text.pollinations.ai/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [
            { role: "system", content: systemPrompt },
            ...newMessages.map(msg => ({ role: msg.role, content: msg.content }))
          ],
          model: 'qwen-coder', // Указываем модель, если требуется
          // Можно добавить другие параметры, если они поддерживаются API
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.text(); // API возвращает текст

      const botMessage = { role: 'assistant', content: data };
      setChatMessages(prevMessages => [...prevMessages, botMessage]);
    } catch (error) {
      console.error("Ошибка при отправке сообщения:", error);
      const errorMessage = { role: 'assistant', content: 'Извините, произошла ошибка при обработке вашего запроса.' };
      setChatMessages(prevMessages => [...prevMessages, errorMessage]);
    } finally {
      setIsBotTyping(false);
    }
  };

  // Обработчик нажатия Enter в поле ввода
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Загрузка...</p>
        </div>
      </div>
    );
  }
  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }
  if (!topic) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Alert className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>Тема не найдена</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2 sm:space-x-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/')}
                className="mr-2"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div className="bg-primary rounded-full p-2">
                <GraduationCap className="h-5 w-5 sm:h-6 sm:w-6 text-primary-foreground" />
              </div>
              <h1 className="text-lg sm:text-xl font-semibold text-gray-900 truncate">
                Образовательная платформа
              </h1>
            </div>
            <div className="flex items-center space-x-2 sm:space-x-4">
              <div className="hidden sm:flex items-center space-x-2">
                <User className="h-4 w-4 text-gray-500" />
                <span className="text-sm text-gray-700">
                  {user?.first_name} {user?.last_name}
                </span>
              </div>
              <Button variant="outline" size="sm" onClick={logout}>
                <LogOut className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">Выйти</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Topic Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <BookOpen className="h-8 w-8 text-blue-500" />
            <div>
              <h2 className="text-3xl font-bold text-gray-900">{topic.title}</h2>
              <p className="text-gray-600 mt-2">{topic.description}</p>
            </div>
          </div>
        </div>

        {/* Topic Content with Markdown Support */}
        {topic.content && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Материалы темы</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-gray max-w-none p-4 bg-white rounded-lg border">
                <ReactMarkdown 
                  remarkPlugins={[remarkGfm]}
                  components={{
                    h1: ({node, ...props}) => <h1 className="text-3xl font-bold mt-6 mb-4" {...props} />,
                    h2: ({node, ...props}) => <h2 className="text-2xl font-bold mt-5 mb-3" {...props} />,
                    h3: ({node, ...props}) => <h3 className="text-xl font-bold mt-4 mb-2" {...props} />,
                    p: ({node, ...props}) => <p className="mb-3 leading-relaxed" {...props} />,
                    ul: ({node, ...props}) => <ul className="list-disc list-inside mb-3 space-y-1" {...props} />,
                    ol: ({node, ...props}) => <ol className="list-decimal list-inside mb-3 space-y-1" {...props} />,
                    li: ({node, ...props}) => <li className="ml-4" {...props} />,
                    strong: ({node, ...props}) => <strong className="font-bold" {...props} />,
                    em: ({node, ...props}) => <em className="italic" {...props} />,
                    a: ({node, ...props}) => <a className="text-blue-600 hover:underline" {...props} />,
                    code: ({node, ...props}) => <code className="bg-gray-100 px-1 py-0.5 rounded text-sm font-mono" {...props} />,
                    pre: ({node, ...props}) => <pre className="bg-gray-800 text-gray-100 p-4 rounded-lg overflow-x-auto my-4" {...props} />,
                    blockquote: ({node, ...props}) => <blockquote className="border-l-4 border-gray-300 pl-4 italic my-4" {...props} />,
                    table: ({node, ...props}) => <table className="min-w-full border-collapse border border-gray-300 my-4" {...props} />,
                    th: ({node, ...props}) => <th className="border border-gray-300 px-4 py-2 bg-gray-50 font-bold" {...props} />,
                    td: ({node, ...props}) => <td className="border border-gray-300 px-4 py-2" {...props} />,
                  }}
                >
                  {topic.content}
                </ReactMarkdown>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Assignments Section */}
        <div className="mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">
            Задания по теме ({assignments.length})
          </h3>
          {assignments.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center text-gray-500">
                По этой теме пока нет заданий
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {assignments.map((assignment) => {
                const status = getAssignmentStatus(assignment);
                const submission = getSubmissionForAssignment(assignment.id);
                return (
                  <Card key={assignment.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardContent className="p-4 sm:p-6" onClick={() => handleAssignmentClick(assignment.id)}>
                      <div className="space-y-4 sm:space-y-0 sm:flex sm:justify-between sm:items-start">
                        <div className="flex-1">
                          <h4 className="text-lg font-semibold text-gray-900 mb-2">
                            {assignment.title}
                          </h4>
                          <p className="text-gray-600 mb-3">{assignment.description}</p>
                          <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 space-y-1 sm:space-y-0 text-sm text-gray-500">
                            <span>Максимальный балл: {assignment.max_score}</span>
                            {assignment.due_date && (
                              <span>
                                Срок: {new Date(assignment.due_date).toLocaleDateString('ru-RU')}
                              </span>
                            )}
                            {submission && submission.is_graded && (
                              <span className="text-green-600 font-medium">
                                Оценка: {submission.score}/{assignment.max_score}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center justify-between sm:justify-end space-x-3">
                          <Badge variant={status.color}>{status.label}</Badge>
                          <Button size="sm" variant={submission ? "outline" : "default"}>
                            {submission ? "Просмотреть" : "Выполнить"}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </main>

      {/* Floating Chat Button */}
      <Button
        className="fixed bottom-6 right-6 rounded-full p-3 shadow-lg z-50"
        size="icon"
        onClick={() => {
          setIsChatOpen(true);
          // Инициализируем чат приветственным сообщением, если это первый раз
          if (chatMessages.length === 0 && topic?.content) {
            const welcomeMessage = { 
              role: 'assistant', 
              content: `Привет! Я ваш помощник по теме "${topic.title}". Задавайте мне вопросы, и я постараюсь ответить, используя информацию из материала темы.`
            };
            setChatMessages([welcomeMessage]);
          }
        }}
      >
        <MessageCircle className="h-6 w-6" />
      </Button>

      {/* Chat Modal */}
      {isChatOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl flex flex-col h-[80vh]">
            {/* Chat Header */}
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="text-lg font-semibold">Чат-помощник</h3>
              <Button variant="ghost" size="sm" onClick={() => setIsChatOpen(false)}>
                <X className="h-5 w-5" />
              </Button>
            </div>

            {/* Chat Messages */}
            <ScrollArea className="flex-grow p-4">
              <div className="space-y-4">
                {chatMessages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        message.role === 'user'
                          ? 'bg-blue-500 text-white'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {message.role === 'assistant' ? (
                        <ReactMarkdown 
                          remarkPlugins={[remarkGfm]}
                          components={{
                            h1: ({node, ...props}) => <h1 className="text-2xl font-bold mt-3 mb-2" {...props} />,
                            h2: ({node, ...props}) => <h2 className="text-xl font-bold mt-2 mb-2" {...props} />,
                            h3: ({node, ...props}) => <h3 className="text-lg font-bold mt-2 mb-1" {...props} />,
                            p: ({node, ...props}) => <p className="mb-2 leading-relaxed" {...props} />,
                            ul: ({node, ...props}) => <ul className="list-disc list-inside mb-2 space-y-1" {...props} />,
                            ol: ({node, ...props}) => <ol className="list-decimal list-inside mb-2 space-y-1" {...props} />,
                            li: ({node, ...props}) => <li className="ml-4" {...props} />,
                            strong: ({node, ...props}) => <strong className="font-bold" {...props} />,
                            em: ({node, ...props}) => <em className="italic" {...props} />,
                            a: ({node, ...props}) => <a className="text-blue-600 hover:underline" {...props} />,
                            code: ({node, ...props}) => <code className="bg-gray-200 px-1 py-0.5 rounded text-sm font-mono" {...props} />,
                            pre: ({node, ...props}) => <pre className="bg-gray-800 text-gray-100 p-3 rounded-lg overflow-x-auto my-2" {...props} />,
                          }}
                        >
                          {message.content}
                        </ReactMarkdown>
                      ) : (
                        <p>{message.content}</p>
                      )}
                    </div>
                  </div>
                ))}
                {isBotTyping && (
                  <div className="flex justify-start">
                    <div className="bg-gray-100 text-gray-800 rounded-lg p-3">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-75"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-150"></div>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Chat Input */}
            <div className="p-4 border-t">
              <div className="flex space-x-2">
                <Input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Введите ваш вопрос..."
                  className="flex-grow"
                  disabled={isBotTyping}
                />
                <Button 
                  onClick={handleSendMessage} 
                  disabled={!inputMessage.trim() || isBotTyping}
                  size="icon"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};