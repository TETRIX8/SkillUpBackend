// src/pages/Profile.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
// Исправленный путь к AuthContext
import { useAuth } from "../contexts/AuthContext";
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  ArrowLeft,
  User,
  Mail,
  Calendar,
  Save,
  AlertCircle,
  Award,
  BookOpen
} from 'lucide-react';
// Исправленный путь к apiClient
import { apiClient } from "../lib/api";
import { motion } from 'framer-motion'; // Импортируем framer-motion

// Варианты анимаций
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: 'spring',
      stiffness: 100
    }
  }
};

export const Profile = () => {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
  });
  const [originalData, setOriginalData] = useState({}); // Для отслеживания изменений
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [stats, setStats] = useState({ topics_completed: 0, assignments_completed: 0 });

  // Инициализируем форму данными пользователя
  useEffect(() => {
    if (user) {
      const initialData = {
        first_name: user.first_name || '',
        last_name: user.last_name || '',
        email: user.email || '',
      };
      setFormData(initialData);
      setOriginalData(initialData);
      // Здесь можно было бы загрузить статистику, если бы API поддерживал
      // Пример имитации:
      // setStats({ topics_completed: user.topics_completed || 0, assignments_completed: user.assignments_completed || 0 });
    }
  }, [user]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const hasChanges = () => {
    return (
      formData.first_name !== originalData.first_name ||
      formData.last_name !== originalData.last_name
      // Обычно email не редактируется, поэтому его не проверяем
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Проверка, есть ли изменения
    if (!hasChanges()) {
      setSuccess('Нет изменений для сохранения');
      setTimeout(() => setSuccess(''), 3000);
      return;
    }
    setLoading(true);
    setError('');
    setSuccess('');
    try {
      // Подготавливаем данные для отправки
      const updateData = {
        first_name: formData.first_name.trim(),
        last_name: formData.last_name.trim(),
        // email обычно не редактируется, поэтому не отправляем
      };
      // 1. Вызываем API для обновления профиля
      const response = await apiClient.updateProfile(updateData);
      // 2. Проверяем, вернул ли API обновленные данные пользователя
      // Предполагаем, API возвращает { user: {...обновленные данные...} }
      if (response && response.user) {
        // 3. Обновляем состояние контекста с новыми данными от API
        updateUser(response.user);
        // 4. Обновляем оригинальные данные для корректного сравнения в будущем
        setOriginalData({
          first_name: response.user.first_name || updateData.first_name,
          last_name: response.user.last_name || updateData.last_name,
          email: response.user.email || formData.email, // Email скорее всего не меняется
        });
      } else {
        // Если API не вернул обновленного пользователя, обновляем локально
        // и надеемся, что данные введены корректно
        updateUser({ ...user, ...updateData });
        setOriginalData({ ...formData }); // Обновляем оригинальные данные
      }
      setSuccess('Профиль успешно обновлён');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error("Ошибка API при обновлении профиля:", err);
      // Проверяем, есть ли сообщение об ошибке в ответе
      let errorMessage = 'Неизвестная ошибка';
      if (err.response?.data?.message) {
        errorMessage = err.response.data.message;
      } else if (err.message) {
        errorMessage = err.message;
      } else if (typeof err === 'string') {
        errorMessage = err;
      }
      setError(`Ошибка при обновлении профиля: ${errorMessage}`);
      // Не останавливаем спиннер/загрузку в случае ошибки, чтобы пользователь видел, что что-то пошло не так
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          {/* Анимированная "звёздочка" */}
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
            className="rounded-full h-16 w-16 mx-auto mb-6 flex items-center justify-center bg-gradient-to-r from-blue-400 to-purple-500 shadow-lg" // Градиентный фон и тень
          >
            <Award className="h-8 w-8 text-white" /> {/* Используем иконку Award как "звёздочку" */}
          </motion.div>
          <motion.p
            initial={{ y: 10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-xl font-medium text-gray-700"
          >
            Загрузка данных пользователя...
          </motion.p>
        </motion.div>
      </div>
    );
  }

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100" // Градиентный фон
    >
      {/* Header */}
      <motion.header
        variants={itemVariants}
        className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-10 shadow-sm" // Стекло, тень, закрепление
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2 sm:space-x-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate(-1)}
                className="mr-2 hover:bg-gray-100 transition-colors"
              >
                <ArrowLeft className="h-4 w-4" />
                <span className="sr-only">Назад</span>
              </Button>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full p-2 shadow-md" // Градиент, тень
              >
                <User className="h-5 w-5 sm:h-6 sm:w-6 text-primary-foreground" />
              </motion.div>
              <motion.h1
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="text-lg sm:text-xl font-bold text-gray-900 truncate bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-700" // Градиентный текст
              >
                Профиль пользователя
              </motion.h1>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-3xl mx-auto space-y-6">
          {/* Profile Info Card */}
          <motion.div variants={itemVariants}>
            <Card className="shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-200"> {/* Тень и анимация */}
              <CardHeader className="bg-gray-50 rounded-t-lg">
                <CardTitle className="flex items-center gap-2 text-gray-800">
                  <User className="h-5 w-5" />
                  Информация профиля
                </CardTitle>
                <CardDescription>
                  Управляйте информацией вашего аккаунта
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                  >
                     <Alert variant="destructive" className="mb-6 shadow-sm">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  </motion.div>
                )}
                {success && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                  >
                    <Alert className="mb-6 bg-green-50 border-green-200 shadow-sm">
                      <AlertCircle className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-green-800">{success}</AlertDescription>
                    </Alert>
                  </motion.div>
                )}
                <form onSubmit={handleSubmit} className="space-y-6">
                  <motion.div
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                    className="grid grid-cols-1 sm:grid-cols-2 gap-4"
                  >
                    <motion.div variants={itemVariants} className="space-y-2">
                      <Label htmlFor="first_name">Имя</Label>
                      <Input
                        id="first_name"
                        name="first_name"
                        value={formData.first_name}
                        onChange={handleChange}
                        placeholder="Введите ваше имя"
                        className="transition-all duration-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </motion.div>
                    <motion.div variants={itemVariants} className="space-y-2">
                      <Label htmlFor="last_name">Фамилия</Label>
                      <Input
                        id="last_name"
                        name="last_name"
                        value={formData.last_name}
                        onChange={handleChange}
                        placeholder="Введите вашу фамилию"
                        className="transition-all duration-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </motion.div>
                    <motion.div variants={itemVariants} className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleChange}
                          className="pl-10 transition-all duration-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          placeholder="Введите ваш email"
                          readOnly // Обычно email не редактируется
                        />
                      </div>
                    </motion.div>
                    <motion.div variants={itemVariants} className="space-y-2">
                      <Label>Дата регистрации</Label>
                      <div className="relative">
                        <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                          value={user?.created_at ? new Date(user.created_at).toLocaleDateString('ru-RU') : 'Не указана'}
                          className="pl-10 transition-all duration-200"
                          readOnly
                        />
                      </div>
                    </motion.div>
                  </motion.div>
                  <motion.div
                    variants={itemVariants}
                    className="flex justify-end"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Button type="submit" disabled={loading || !hasChanges()} className="transition-all duration-200 bg-blue-600 hover:bg-blue-700">
                      {loading ? (
                        <>
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                            className="mr-2 h-4 w-4"
                          >
                            <Award className="h-4 w-4" /> {/* Используем Award как спиннер */}
                          </motion.div>
                          Сохранение...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Сохранить изменения
                        </>
                      )}
                    </Button>
                  </motion.div>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          {/* Stats Card */}
          <motion.div variants={itemVariants}>
            <Card className="shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-200"> {/* Тень и анимация */}
              <CardHeader className="bg-gray-50 rounded-t-lg">
                <CardTitle className="flex items-center gap-2 text-gray-800">
                  <Award className="h-5 w-5" />
                  Статистика
                </CardTitle>
                <CardDescription>
                  Ваша активность на платформе
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <motion.div
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="grid grid-cols-1 sm:grid-cols-2 gap-4"
                >
                  <motion.div
                    variants={itemVariants}
                    whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)" }} // Подъем и тень при наведении
                    className="p-4 bg-white rounded-lg text-center border border-gray-200 transition-all duration-300"
                  >
                    <BookOpen className="h-8 w-8 mx-auto text-blue-500 mb-2" />
                    <div className="text-2xl font-bold text-gray-900">{stats.topics_completed}</div>
                    <div className="text-sm text-gray-600">Завершенных тем</div>
                  </motion.div>
                  <motion.div
                    variants={itemVariants}
                    whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)" }}
                    className="p-4 bg-white rounded-lg text-center border border-gray-200 transition-all duration-300"
                  >
                    <Award className="h-8 w-8 mx-auto text-green-500 mb-2" />
                    <div className="text-2xl font-bold text-gray-900">{stats.assignments_completed}</div>
                    <div className="text-sm text-gray-600">Выполненных заданий</div>
                  </motion.div>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>
    </motion.div>
  );
};